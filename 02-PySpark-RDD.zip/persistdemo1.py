# Create an RDD from the text file

lines = sc.textFile("war_and_peace.txt",4)
type(lines)

# Run an action on the RDD to make sure that the above line of creating RDD is executed
lines.count()

# Now rename or delete the input file and run the following lines
nonNullLines = lines.filter(lambda line: len(line)>0)
words = nonNullLines.flatMap(lambda line: line.split())

# Now run the following action to make sure that the above lines are executed

words.count()

# Note that though the fils is read and RDD is created for the first action, for next actions again the file will be read.
# As the file is renamed or deleted we will get an error message since it cannot be read for creating the RDD
