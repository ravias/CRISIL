# You can run this file with the command
# spark-submit --master local[*] <this file name>
# However you need to create the spark session object using the three lines below 

import pyspark
from pyspark.sql import SparkSession
spark = SparkSession.builder.appName("PySpark SQL Functions - Examples").getOrCreate()

spark.sparkContext.setLogLevel("ERROR")

from pyspark.sql.functions import *
from pyspark.sql.types import *

# Define the schema for the static file of previous max price
schema1 = StructType([
                    StructField("symbol1", StringType(), False),
                    StructField("prevmaxprice", DoubleType(), False)
                    ])

# Load the file into a dataframe
prevmaxdf = spark.read.csv('previous_max_price.csv', schema=schema1)

prevmaxdf.printSchema()
prevmaxdf.show(5)

# Define the schema for the streaming table/dataframe`	
schema2 = StructType([
                    StructField("symbol2", StringType(), False),
                    StructField("tstamp", StringType(), False),
                    StructField("currentprice", DoubleType(), False)
                    ])

streamdf = spark.readStream.schema(schema2).option("sep", ",").csv("G:\\MR2\\Unext\\CRISIL\\stockstreamdata\\")

joindf=streamdf.join(prevmaxdf,streamdf.symbol2==prevmaxdf.symbol1)

filtereddf=joindf.where(joindf.currentprice>=joindf.prevmaxprice)

filtereddf.writeStream.format('console').start().awaitTermination()

# Let us simulate streaming data in the above folder
# Transfer the first file to the above folder
# groupby operation will start and the result will be displayed

# Now you will notice the groupby operation is run by spark on the existing data and result gets displayed

# Now transfer the next file data2.csv to the above directory
# The groupby computation will get started again by spark structured streaming and the result including the previous data is displayed again.

# We can trnsfer the other data csv files one by one. Each time we transfer a file the stream is read and the computation is performed.
# Since we specified output mode as complete the complete data is taken for the computation i.e. the group by aggregation.
